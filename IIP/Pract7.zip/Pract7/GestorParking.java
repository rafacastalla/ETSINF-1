import java.util.Scanner;
import java.util.Locale;
/** Clase GestorParking: gestor d'un parking.
  * @author IIP
  * @version Curs 2015/2016
  */
public class GestorParking {

    /**
     * Mostra un menu d'opcions per pantalla i
     * llig des de teclat una opcio valida.
     * @param tec Scanner que representa el teclat.
     * @return int, opcio valida.
     */  
  

    /**
     * Lectura des de teclat d'una hora valida.
     * @param tec Scanner que representa el teclat.
     * @return Hora, hora valida.
     */
   
  
    /**
     * Metode principal.
     * @param args String[].  
     * @throws Exception si ocorre algun error d'entrada/eixida.
     */
    public static void main(String [] args) throws Exception {
        Scanner tec = new Scanner(System.in).useLocale(Locale.US);
    
	    // COMPLETAR
    
    }
  
}
