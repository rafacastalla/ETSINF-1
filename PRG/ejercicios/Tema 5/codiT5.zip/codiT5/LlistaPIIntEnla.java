import java.util.NoSuchElementException;
/**
 * LlistaPIIntEnla: Implementació enllaçada de l'estructura de dades 
 * lineal Llista amb punt d'interès d'enters.
 * 
 * @author PRG
 * @version Curs 2015/16
 */
public class LlistaPIIntEnla {
    // referencies al primer, al PI i a l'anterior de la llista
    private NodeInt primer, PI, antPI;    
    private int talla;       // número d'elements de la llista
    
    /**
     * Crea una llista buida.
     */
    public LlistaPIIntEnla() {
        primer = null;
        PI = null;
        antPI = null;
        talla = 0;
    }

    /**
     * Comprova si la llista actual està o no buida.
     * @return boolean, true si la llista està buida i false en cas contrari.
     */
    public boolean esBuida() { 
        return talla == 0;   // Alternativament: return primer == null;
    }
    
    /**
     * Comprova si el punt d'interès està al final de la llista actual.
     * @return boolean, true si el PI està al final de la llista i false 
     * en cas contrari.
     */
    public boolean esFi() { return PI == null; }
    
    /**
     * Torna el número d'elements de la llista actual.
     * @return int, número d'elements de la llista actual.
     */
    public int talla() { return talla; }      

    /**
     * Situa el punt d'interès en la primera posició de la llista actual.
     */
    public void inici() { 
        PI = primer; 
        antPI = null; 
    }

    /**
     * Desplaça el PI una posició cap a la dreta. 
     * @throws NoSuchElementException si el PI es troba al final de la llista.
     */
    public void seguent() { 
        if (PI == null) { 
            throw new NoSuchElementException("Cursor al final");
        }
        antPI = PI; 
        PI = PI.seguent;
    }
    
    /**
     * Torna l'element en el PI. 
     * @throws NoSuchElementException si el PI es troba al final de la llista.
     * @return int, element en el PI de la llista.
     */
    public int recuperar() { 
        if (PI == null) { 
            throw new NoSuchElementException("Cursor al final");
        }
        return PI.dada; 
    }   

    /**
     * Insereix un nou node amb l'element x en la posició anterior al PI. 
     * Si el cursor està a l’inici, el nou node serà el primer de la 
     * llista. En qualsevol altre cas, el nou node s’insereix entre el 
     * node cursor i el seu node predecessor.
     * @param x, element a afegir en la llista.
     */
    public void inserir(int x) {
        if (PI == primer) { 
            primer = new NodeInt(x, PI); 
            antPI = primer; 
        } 
        else { 
            antPI.seguent = new NodeInt(x, PI); 
            antPI = antPI.seguent; 
        } 
        talla++;
    }
    
    /**
     * Torna i elimina de la llista l'element en el PI. 
     * Si el cursor està a l’inici, primer s’actualitza al seu node 
     * següent. En qualevol altre cas, els nodes anterior i posterior 
     * al node cursor queden enllaçats.
     * @throws NoSuchElementException si el PI es troba al final de la llista.
     * @return int, element en el PI de la llista.
     */
    public int eliminar() {
        if (PI == null) { 
            throw new NoSuchElementException("Cursor al final");
        }
        int x = PI.dada; 
        if (PI == primer) { primer = primer.seguent; }
        else { antPI.seguent = PI.seguent; }
        PI = PI.seguent; 
        talla--; 
        return x;
    }
  
    /*************** MÈTODES DELS EXERCICIS ******************************/   
    /**
     * Mètode privat auxiliar que busca la primera ocurrència de x 
     * des del node aux en endavant; si el troba, mou el PI al node 
     * que conté a x. Si no apareix, el PI no es mou.
     * @param aux NodeInt a partir del qual es fa la cerca
     * @param x int a buscar
     * @return boolean true si el troba i false en cas contrari.
     */
    private boolean buscar(NodeInt aux, int x) { 
        NodeInt ant = null;
        if (aux == this.PI) { ant = this.antPI; }
        while (aux != null && aux.dada != x) {
            ant = aux;
            aux = aux.seguent;
        }
        boolean res = false;
        if (aux != null) {
            this.PI = aux;
            this.antPI = ant;
            res = true;
        }
        return res;
    }
    
    /**
     * Busca la primera ocurrència de x des del primer node de la llista; 
     * si el troba, mou el PI al node que conté a x. Si no apareix, el PI 
     * no es mou.
     * @param x int a buscar
     * @return boolean true si el troba i false en cas contrari.
     */
    public boolean buscarInici(int x) { return buscar(primer, x); } 
    
    /**
     * Busca la primera ocurrència de x des del node del PI (inclusivament) 
     * de la llista; si el troba, mou el PI al node que conté a x. Si no 
     * apareix, el PI no es mou.
     * @param x int a buscar
     * @return boolean true si el troba i false en cas contrari.
     */
    public boolean buscarSeguent(int x) { return buscar(PI, x); }
    
}
